# Jeevan DK — Portfolio

Dark, classic 3D, interactive portfolio for **Jeevan DK**
- B.Tech Computer Science (AI & ML) — REVA University, 2021–2025
- Operations Management & QA SME — Instawork, Bengaluru
- Projects: AI Travel Planner App, Fraud Detection System

Live demo is a single static file — no build step, no backend.

## What's in this folder

| File | What it is |
|------|------------|
| `index.html` | The whole portfolio — open it, or publish it. Your photo is already embedded inside, so it works on its own. |
| `profile.jpg` | Your profile photo (same one used in the portfolio) — keep it for LinkedIn / future edits. |
| `.nojekyll` | Tells GitHub Pages to serve the site exactly as-is. Do not delete it. |

## Publish on GitHub Pages (2 minutes, free)

### Option A — Fastest: Upload in the browser

1. Go to https://github.com/new and create a repo, e.g. `jeevan-portfolio`
   - Choose **Public**
   - Tick **Add a README file** (you can replace it later)
   - Click **Create repository**
2. On the repo page, click **Add file → Upload files**
3. Drag in `index.html`, `profile.jpg`, and `.nojekyll` from this folder
   - Note: GitHub's web upload hides dotfiles sometimes. If `.nojekyll` doesn't upload, click **Add file → Create new file**, name it `.nojekyll`, leave it empty, and commit.
4. Click **Commit changes**
5. Go to **Settings → Pages** (left sidebar)
   - Under **Build and deployment → Branch**, choose `main` and `/ (root)`, click **Save**
6. Wait 30–60 seconds. Your link will appear at the top of the Pages settings:
   `https://<your-username>.github.io/jeevan-portfolio/`

### Option B — From your computer (Git)

```bash
# 1. Go into this folder
cd jeevan-portfolio-github

# 2. Start git and push
git init
git add index.html profile.jpg .nojekyll
git commit -m "Publish Jeevan DK portfolio"
git branch -M main
git remote add origin https://github.com/<your-username>/jeevan-portfolio.git
git push -u origin main
```

Then do step 5 from Option A to turn on Pages.

### Option C — Custom domain (optional)

If you own a domain (e.g. `jeevandk.com`):
1. In **Settings → Pages → Custom domain**, enter your domain and Save.
2. At your domain provider, add a `CNAME` record pointing to `<your-username>.github.io`
3. Tick **Enforce HTTPS** once it appears.

## Update it later

- Edit `index.html` in any text editor (VS Code, Notepad) — search for your name, role, or project to find the spot.
- To change the photo: replace the `data:image/...` photo in `index.html`, or replace `profile.jpg` and update the `<img>` / background to point to `profile.jpg`.
- Re-upload / `git push` again — GitHub Pages updates automatically in ~1 minute.

## Contact in the portfolio

- Email: dkjeevan52@gmail.com
- Phone: +91 93806 64663
- Location: Bengaluru, Karnataka 560072
